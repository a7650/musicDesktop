<template>
  <header>
    <slot></slot>
  </header>
</template>

<script>
export default {};
</script>

<style lang="less" scoped>
@import "~common/less/variable.less";
@import "~common/less/mixin.less";
header {
  margin-top: 20px;
  width: 100%;
  height: 80px;
  line-height: 80px;
  text-align: center;
  font-size: 26px;
  font-weight: 600;
  //   min-width: 1200px;
}
</style>

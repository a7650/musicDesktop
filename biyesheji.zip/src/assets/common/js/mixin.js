
import float from "base/float/float"

export const float = {
    components:{
        float
    }
}
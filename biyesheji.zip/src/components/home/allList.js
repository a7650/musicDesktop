const allList = [{
    item_id: 64,
    item_name: "KTV热歌",
},
{
    item_id: 132,
    item_name: "运动",
},
{
    item_id: 42,
    item_name: "说唱",
},
{
    item_id: 71,
    item_name: "情歌",
},
{
    item_id: 3056,
    item_name: "网络歌曲",
},
{
    item_id: 59,
    item_name: "经典",
},
{
    item_id: 107,
    item_name: "背景音乐",
},
{
    item_id: 74,
    item_name: "伤感",
},
{
    item_id: 3,
    item_name: "英语",
},
{
    item_id: 1,
    item_name: "国语",
},
{
    item_id: 45,
    item_name: "电子",
},
{
    item_id: 46,
    item_name: "爵士",
},
{
    item_id: 49,
    item_name: "轻音乐",
},
{
    item_id: 142,
    item_name: "90年代",
}
];

export default allList
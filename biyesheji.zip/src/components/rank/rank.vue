<template>
  <div class="rank">
      <header>
          排行榜
      </header>
      <div class="rank-content">
          <ul class="items">
              <li v-for="item in topList" :key="item.id" class="item">
                  
              </li>
          </ul>
      </div>
  </div>
</template>
<script>
import { getRankList } from "api/rank";
import loading from "base/loading/loading";
import { mapMutations } from "vuex";
export default {
  data() {
    return {
      topList: []
    };
  },
  components: {
    loading
  },
  methods: {
    _getRankList() {
      getRankList().then(
        data => {
          this.topList = data.topList;
          console.log(this.topList)
        },
        err => {
          console.log(err);
        }
      );
    },
    selectList(item, index) {
      this.currentList = index;
      this.$router.push({
        name: "rankDetail",
        params: {
          topid: item.id
        }
      });
      this.SET_SINGER(item);
    },
    ...mapMutations(["SET_SINGER"])
  },
  created() {
    this._getRankList();
  }
};
</script>

<style lang="less" scoped>
@import "~common/less/variable.less";
@import "~common/less/mixin.less";
.rank {
  position: absolute;
  padding-top: 80px;
  width: 100%;
  color: #000;
  min-width: 1200px;
  padding-bottom: 100px;
}
header {
  margin-top: 20px;
  width: 100%;
  height: 80px;
  line-height: 80px;
  text-align: center;
  font-size: 26px;
  font-weight: 600;
  min-width: 1200px;
}
.rank-content {
  width: 1200px;
  height: 700px;
  box-sizing: border-box;
  margin: 0 auto;
  position: relative;
}
</style>

<template>
    <div class="mine">
        #mine
    </div>
</template>

<script>
export default {

}
</script>

<style lang="less" scoped>
@import "~common/less/variable.less";
@import "~common/less/mixin.less";
.mine{
    position: absolute;
    top: 80px;
    left: 0;
    right: 0;
    bottom: 0;
    color: #000;
}
</style>

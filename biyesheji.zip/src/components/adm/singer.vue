<template>
    
</template>

<script>
export default {

}
</script>

<style lang="less" scoped>
@import "~common/less/variable.less";
@import "~common/less/mixin.less";

</style>
